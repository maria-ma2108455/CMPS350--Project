export default class User {
    
    constructor(username, password, type) {
        this.username = username
        this.password = password
        this.type = type
    }

}